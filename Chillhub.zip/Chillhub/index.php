<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Chill Hub</title>

    <!-- CSS LINKS -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/searchbar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- JS LINKS -->
    <script src="https://kit.fontawesome.com/451ff1b968.js" crossorigin="anonymous" defer></script>
</head>
<body>
    
    <div class="bar">
        <div class="bar-flex">
            <div class="bar-left">
                <img width="300px" height="auto" src="media/chillhubhh.png" alt="jpg/png">
            </div>

            <div class="bar-flex-right">
                <div class="bar-right-upper">
                    <div class="search-container">
                        <!-- moet nog een form worden met php voor goede search bar -->
                        <input type="text" placeholder="Search.." name="search">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </div>

                    <div class="login-signup">
                        <a href="#">Log in /</a>
                        <a href="#">Sign up</a>
                    </div>
                </div>

                <div class="bar-right-under">
                    <a href="#">All</a>
                    <a href="#">Add to favourites+</a>
                </div>
            </div>
        </div>
    </div>

    <div class="mid-section">
        <div class="main-bar-left">
            <div class="container">
                <div class="content">
                    <a href="#"><i class="fa-solid fa-house"></i> Home</a>
                    <a href="#"><i class="fa-solid fa-magnifying-glass"></i> Browse</a>
                    <a href="#"><i class="fa-solid fa-fire"></i> Trending</a>
                </div>
            </div>
            <div class="container">
                <div class="content">
                    <p>
                        Voor meer opties<br>
                        te hebben. <br><br>
                        <a href="#"><i class="fa-solid fa-user"></i> Log in</a>
                    </p>
                </div>
            </div>
            <div class="container-under">
                <div class="content">
                    <a href="#"><i class="fa-solid fa-gear"></i> Instellingen</a>
                </div>
            </div>
        </div>
        <div class="main">
            
        </div>
    </div>

</body>
</html>